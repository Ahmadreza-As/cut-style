<?php
include 'db.php';
try {

    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['auth']) && isset($_POST['newicon'])) {
        $auth = trim($_POST['auth']);
        $newname = trim($_POST['newicon']);





 $stmt = $pdo->prepare("SELECT ban FROM loginn WHERE auth = :auth");
        $stmt->execute(['auth' => $auth]);
        $row2 = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row2 && $row2["ban"] == "yes") {
            echo "error ban";
            exit;
        } else {
          
        $stmt = $pdo->prepare("SELECT * FROM loginn WHERE auth = :auth");
        $stmt->execute(['auth' => $auth]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            
            $stmt = $pdo->prepare("UPDATE loginn SET icon = :icon WHERE auth = :auth");
            $stmt->execute(['icon' => $newname, 'auth' => $auth]);
            echo "ok";
        } else {
            echo "کاربر یافت نشد.";
        }
        }
    } else {
        echo "error";
    }
} catch (PDOException $e) {
    echo "خطا در اتصال به دیتابیس: " . $e->getMessage();
}
?>