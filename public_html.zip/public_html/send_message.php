<?php
include 'db.php';

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $auth = $_POST['auth'];


    $stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = :auth");
    $stmt->execute(['auth' => $auth]);
    $row22 = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row22 && $row22["ban"] == "yes") {
        echo "error ban";
        exit;
    } else {

        $sql_search_username = "SELECT username, name, icon, tik FROM loginn WHERE auth=:auth";
        $stmt = $conn->prepare($sql_search_username);
        $stmt->bindParam(':auth', $auth);
        $stmt->execute();
        $result_search_username = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result_search_username) {
            $sender = $result_search_username["username"];
            $name = $result_search_username["name"];
            $icon3 = $result_search_username["icon"];
            $tik3 = $result_search_username["tik"];
        } else {
            echo "No results found for the provided auth.";
            exit;
        }

        $a1 = $_POST['a1'];
        $a2 = $_POST['a2'];

        $sql_check_existence = "SELECT * FROM messages WHERE (sender=:a1 AND receiver=:a2) OR (sender=:a2 AND receiver=:a1)";
        $stmt = $conn->prepare($sql_check_existence);
        $stmt->bindParam(':a1', $a1);
        $stmt->bindParam(':a2', $a2);
        $stmt->execute();
        $result_check_existence = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result_check_existence) {
            echo "Error: One or both inputs already exist in the messages table.";
            exit;
        }

        $receivere = $_POST['receiver'];
        $get = "SELECT * FROM loginn WHERE username=:receivere";
        $stmt = $conn->prepare($get);
        $stmt->bindParam(':receivere', $receivere);
        $stmt->execute();
        $result_get = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result_get) {
            $receiver = $result_get["username"];
            $name2 = $result_get["name"];
            $icon2 = $result_get["icon"];
            $tik2 = $result_get["tik"];
        } else {
            echo "No results found for the provided receiver.";
            exit;
        }

        $file = $sender . "_" . $receiver . "_" . rand(10000000, 90000000) . ".json";
        $text = "[]";
        $path = "pm/" . $file;

        $sql_check = "SELECT * FROM messages WHERE (sender=:sender AND receiver=:receiver) OR (sender=:receiver AND receiver=:sender)";
        $stmt = $conn->prepare($sql_check);
        $stmt->bindParam(':sender', $sender);
        $stmt->bindParam(':receiver', $receiver);
        $stmt->execute();
        $result_check = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result_check) {

            $sql = "INSERT INTO messages (sender, receiver, usender, ureceiver, file) VALUES (:sender, :receiver, :usender, :ureceiver, :file)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':sender', $sender);
            $stmt->bindParam(':receiver', $receiver);
            $stmt->bindParam(':usender', $name);
            $stmt->bindParam(':ureceiver', $name2);
            $stmt->bindParam(':file', $file);
            if ($stmt->execute()) {
                
                file_put_contents($path, $text);
                
                $sql_get_file = "SELECT file FROM messages WHERE sender=:sender AND receiver=:receiver";
                $stmt = $conn->prepare($sql_get_file);
                $stmt->bindParam(':sender', $sender);
                $stmt->bindParam(':receiver', $receiver);
                $stmt->execute();
                $result_file = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($result_file) {
                    $file2 = $result_file["file"];

                    $ahmad[] = array(
                        'name' => $name2,
                        'username' => $receiver,
                        'icon' => $icon2,
                        'tik' => $tik2,
                        'file' => $file2
                    );
                    echo json_encode($ahmad);
                }
            } else {
            
            if ($receivere == $sender) {
                echo "errortr";
            } else {
                
                $sql_get_file = "SELECT file FROM messages WHERE sender=:sender AND receiver=:receiver";
                $stmt = $conn->prepare($sql_get_file);
                $stmt->bindParam(':sender', $sender);
                $stmt->bindParam(':receiver', $receiver);
                $stmt->execute();
                $result_file = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($result_file) {
                    $file2 = $result_file["file"];

                    $ahmad2[] = array(
                        'name' => $name,
                        'username' => $sender,
                        'icon' => $icon3,
                        'tik' => $tik3,
                        'file' => $file2
                    );
                    echo json_encode($ahmad2);
                }
            }
        }
        }}
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>