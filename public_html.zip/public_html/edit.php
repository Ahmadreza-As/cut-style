<?php
include 'db.php';
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$auth = $_POST['auth'];

$sql_check_ban = "SELECT ban FROM loginn WHERE auth='$auth'";
$result_check_ban = $conn->query($sql_check_ban);

if ($result_check_ban->num_rows > 0) {
    $row2 = $result_check_ban->fetch_assoc();
    
    if ($row2["ban"] == "yes") {
        echo "error ban";
        exit;
    }
}
          
         
$sql_search_username = "SELECT username FROM loginn WHERE auth='$auth'";
$result_search_username = $conn->query($sql_search_username);

if ($result_search_username->num_rows > 0) {




$jsonFile = $_POST['name'];

$jsonData = file_get_contents("pm/" . $jsonFile);

$data = json_decode($jsonData, true);

$keyInput = $_POST['key'];

$keyIndex = array_search($keyInput, array_column($data, 'key'));

if ($keyIndex !== false) {

    $text = $_POST['text'];

    $data[$keyIndex]['text'] = $text;
    
    $data[$keyIndex]['edit'] = 'yes';

    $newJsonData = json_encode($data, JSON_PRETTY_PRINT | JSON_NUMERIC_CHECK);

    file_put_contents("pm/" . $jsonFile, $newJsonData);
}
    echo "ok";
} else {
    echo "error";
}

  $conn->close();
?>