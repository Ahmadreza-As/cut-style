<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$input = $_POST['input'];
$pass = $_POST["pass"];


$stmt = $conn->prepare("SELECT * FROM loginn WHERE number = ?");
$stmt->bind_param("s", $input);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hpass = $row["pass"];
    $us = $row["username"];
    if ($us == "") {
        echo "false";
    } else {
    
    if ($pass == $hpass) {
        $auth = $row['auth'];
        echo $auth;
    
    } else {
        echo "error pass";
    }}
} else {
    echo "false";
}

$stmt->close();
$conn->close();
?>
