<?php
include 'db.php';
$auth = $_POST["auth"];

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $auth);
$stmt->execute();
$result_ban = $stmt->get_result();

if ($result_ban->num_rows > 0) {
    $row2 = $result_ban->fetch_assoc();
    if ($row2["ban"] == "yes") {
        echo "error ban";
        exit;
    }
} else {
    echo "کاربر یافت نشد.";
    exit;
}

$sql = "SELECT username, name, number, bio, icon, idn FROM loginn WHERE auth = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $auth);
$stmt->execute();
$result = $stmt->get_result();

$ahmad = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $ahmad[] = array(
            'username' => $row["username"],
            'name' => $row["name"],
            'number' => $row["number"],
            'bio' => $row["bio"],
            'icon' => $row["icon"],
            'id' => $row["idn"]
        );
    }
    echo json_encode($ahmad);
} else {
    echo "error";
}

// بستن اتصال
$stmt->close();
$conn->close();
?>