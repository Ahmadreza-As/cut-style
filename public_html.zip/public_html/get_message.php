<?php
include 'db.php';
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$auth = $_POST['auth'];

$stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $auth);
$stmt->execute();
$result_ban = $stmt->get_result();

if ($result_ban->num_rows > 0) {
    $row2 = $result_ban->fetch_assoc();
    if ($row2["ban"] == "yes") {
        echo "error ban";
        $conn->close();
        exit;
    }
} else {
    echo "کاربر یافت نشد.";
    $conn->close();
    exit;
}

$sql_search_username = "SELECT username FROM loginn WHERE auth = ?";
$stmt_username = $conn->prepare($sql_search_username);
$stmt_username->bind_param("s", $auth);
$stmt_username->execute();
$result_search_username = $stmt_username->get_result();

if ($result_search_username->num_rows > 0) {
    
    $name = $_POST['name'];
    $data = file_get_contents("pm/" . $name);
    echo $data;
} else {
    echo 'error';
}

$conn->close();
?>