<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$PhoneNumber = htmlspecialchars(trim($_POST['PhoneNumber']));
$OTP = htmlspecialchars(trim($_POST['OTP']));
$otppost = array('Phone' => $PhoneNumber, 'OTP' => $OTP); 
$options = array( 
'http' => array( 
'method' => 'POST', 
'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
'content' => http_build_query($otppost)
)
);
$context = stream_context_create($options);

$URL_GET_RESULT = "https://api.siteesho.com/api/users/verify/{$PhoneNumber}/{$OTP}";
$Res = file_get_contents($URL_GET_RESULT, false, $context);

$sql_check_phone = "SELECT auth FROM loginn WHERE number=?";
$stmt = $conn->prepare($sql_check_phone);
$stmt->bind_param("s", $PhoneNumber);
$stmt->execute();
$result_check_phone = $stmt->get_result();

if ($result_check_phone->num_rows > 0) {

$row = $result_check_phone->fetch_assoc();
echo "ok2";
} else {

if ($Res === '{}') {

$sql_insert = "INSERT INTO loginn (number, code) VALUES (?, ?)";

$stmt_insert = $conn->prepare($sql_insert);
$stmt_insert->bind_param("ss", $PhoneNumber, $OTP);

if ($stmt_insert->execute()) {
echo "ok";
} else {
echo "Error: " . $stmt_insert->error;
}

$stmt_insert->close();
} else {
echo "error code";
}
}

$stmt->close();
$conn->close();
?>