<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the input username
$myUsername = $_POST["auth"];

// Check if the user is banned
$stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $myUsername);
$stmt->execute();
$result_ban = $stmt->get_result();

if ($result_ban->num_rows > 0) {
    $row2 = $result_ban->fetch_assoc();
    if ($row2["ban"] == "yes") {
        echo "error ban";
        $conn->close();
        exit;
    }
} else {
    echo "کاربر یافت نشد.";
    $conn->close();
    exit;
}

$stmt = $conn->prepare("SELECT username FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $myUsername);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch the corresponding username from the 'auth' table
    $row = $result->fetch_assoc();
    $myUsername = $row['username'];

    $sql = "SELECT * FROM messages WHERE sender = ? OR receiver = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $myUsername, $myUsername);
    $stmt->execute();
    $result = $stmt->get_result();

    $messageList = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $filePath = "pm/" . $row['file'];
            if (file_exists($filePath)) {
                $fileContent = file_get_contents($filePath);
                $jsonData = json_decode($fileContent, true);
                
                if (is_array($jsonData) && count($jsonData) > 0) {
                
                    $lastRow = end($jsonData);
                    $lastText = $lastRow['text'];
                } else {
                    $lastText = "not pm";
                }
            } else {
                $lastText = "not pv";
            }

            $senderIconCheck = $conn->prepare("SELECT icon, tik, ban FROM loginn WHERE username = ?");
            $senderIconCheck->bind_param("s", $row['sender']);
            $senderIconCheck->execute();
            $senderIconResult = $senderIconCheck->get_result();
            $senderIcon = $senderIconResult->num_rows > 0 ? $senderIconResult->fetch_assoc() : null;
            $receiverIconCheck = $conn->prepare("SELECT icon, tik, ban FROM loginn WHERE username = ?");
            $receiverIconCheck->bind_param("s", $row['receiver']);
            $receiverIconCheck->execute();
            $receiverIconResult = $receiverIconCheck->get_result();
            $receiverIcon = $receiverIconResult->num_rows > 0 ?
            $receiverIconResult->fetch_assoc() : null;

            $messageList[] = array(
                'sender' => $row['sender'],
                'receiver' => $row['receiver'],
                'usender' => $row["usender"],
                'ureceiver' => $row["ureceiver"],
                'file' => $row['file'],
                'lastText' => $lastText,
                'iconsender' => $senderIcon['icon'] ?? null,
                'iconreceiver' => $receiverIcon['icon'] ?? null,
                'tiksender' => $senderIcon['tik'] ?? null,
                'tikreceiver' => $receiverIcon['tik'] ?? null,
                'banreceiver' => $receiverIcon['ban'] ?? null,
                'bansender' => $senderIcon['ban'] ?? null,
            );
        }
    }

    echo json_encode($messageList);
} else {
    echo json_encode(['error' => 'User not found']);
}

$conn->close();
?>