<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = htmlspecialchars(trim($_POST['name']));
$pass = $_POST['pass'];
$number = htmlspecialchars(trim($_POST['number']));
$input_username = htmlspecialchars(trim($_POST['username']));
$bio = "no";
$icon = "no";
$idn = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, 10);
$auth = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, 15);
$ban = "no";

$sql_check_number_code = "SELECT number, code, username FROM loginn WHERE number=?";
$stmt = $conn->prepare($sql_check_number_code);
$stmt->bind_param("s", $number);
$stmt->execute();
$result_check_number_code = $stmt->get_result();

if ($result_check_number_code->num_rows > 0) {
    $row = $result_check_number_code->fetch_assoc();
    
    if (empty($row['code'])) {
        echo "Error: code is empty";
    } else {
        $sql_delete = "DELETE FROM loginn WHERE number=?";
        $stmt = $conn->prepare($sql_delete);
        $stmt->bind_param("s", $number);
        $stmt->execute();

        $sql_insert = "INSERT INTO loginn (name, number, pass, bio, icon, idn, auth, ban, username) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("sssssssss", $name, $number, $pass, $bio, $icon, $idn, $auth, $ban, $input_username);

        if ($stmt->execute()) {
            echo "OK";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
} else {
    echo "Error: No record found for this username.";
}

$stmt->close();
$conn->close();
?>