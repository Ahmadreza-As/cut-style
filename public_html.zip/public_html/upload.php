<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$auth = $_GET['auth'];

$stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $auth);
$stmt->execute();
$result = $stmt->get_result();
$row2 = $result->fetch_assoc();

if ($row2 && $row2["ban"] == "yes") {
    echo "error ban";
    exit;
}

$sql_search_username = "SELECT username FROM loginn WHERE auth=?";
$stmt_username = $conn->prepare($sql_search_username);
$stmt_username->bind_param("s", $auth);
$stmt_username->execute();
$result_search_username = $stmt_username->get_result();

if ($result_search_username->num_rows > 0) {
    $row_username = $result_search_username->fetch_assoc();

    // Check if a file is uploaded
    if (isset($_FILES['bill'])) {
        $bill = $_FILES['bill'];

        $target_dir = "uploads/";
        $max_file_size = 50 * 1024 * 1024;

        $random_number = generateRandomNumber(18);
        $fileExtension = strtolower(pathinfo($bill["name"], PATHINFO_EXTENSION));
        $filename = "pido_" . $random_number . "." . $fileExtension;
        $target_file = $target_dir . $filename;

        // Check file size
        if ($bill["size"] > $max_file_size) {
            echo "Sorry, your file is too large. Maximum allowed size is 50MB.";
            exit;
        }

        // Allowed file types
        $allowed_types = array("jpg", "jpeg", "png", "gif", "zip", "svg", "mp4", "mp3", "apk", "rar", "pdf");

        if (!in_array($fileExtension, $allowed_types)) {
            echo "Error: Invalid file type. Allowed types are: " . implode(", ", $allowed_types);
            exit;
        }

        // Move the uploaded file
        if (move_uploaded_file($bill["tmp_name"], $target_file)) {
            echo "https://pido-chat.ir/uploads/" . $filename;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "No file was uploaded.";
    }
} else {
    echo "Error: User not found.";
}

$stmt->close();
$stmt_username->close();
$conn->close();

function generateRandomNumber($length) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>