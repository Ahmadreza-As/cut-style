<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$auth = $_POST['auth'];

$stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $auth);
$stmt->execute();
$result_ban = $stmt->get_result();
$row2 = $result_ban->fetch_assoc();

if ($row2 && $row2["ban"] == "yes") {
    echo "error ban";
    exit;
} else {
    
    $sql_search_username = $conn->prepare("SELECT username FROM loginn WHERE auth = ?");
    $sql_search_username->bind_param("s", $auth);
    $sql_search_username->execute();
    $result_search_username = $sql_search_username->get_result();

    if ($result_search_username->num_rows > 0) {
    
        $input = $_POST['username'];
        $stmt = $conn->prepare("SELECT * FROM loginn WHERE username = ?");
        $stmt->bind_param("s", $input);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $ahmad[] = array(
                'user' => $row["username"],
                'name' => $row["name"],
                'bio' => $row["bio"],
                'icon' => $row["icon"]
            );
            echo json_encode($ahmad);
        } else {
            echo "false";
        }
    } else {
        echo 'error';
    }
}

$stmt->close();
$conn->close();
?>