<?php
$PhoneNumber = $_GET['PhoneNumber'];
$URL_SEND_CODE = "https://api.siteesho.com/api/users/otp/userFree/{$PhoneNumber}";
		$Res = file_get_contents($URL_SEND_CODE);
		echo $Res;
		
		
		?>