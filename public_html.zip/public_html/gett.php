<?php

include 'db.php';
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$auth = $_POST['username'];

$stmt = $conn->prepare("SELECT ban FROM loginn WHERE username = ?");
$stmt->bind_param("s", $auth);
$stmt->execute();
$result = $stmt->get_result();
$row2 = $result->fetch_assoc();

if ($row2 && $row2["ban"] == "yes") {
    echo "error ban";
    exit;
} else {

    $sql_search_username = $conn->prepare("SELECT tik FROM loginn WHERE username = ?");
    $sql_search_username->bind_param("s", $auth);
    $sql_search_username->execute();
    $result_search_username = $sql_search_username->get_result();

    if ($result_search_username->num_rows > 0) {
        $row = $result_search_username->fetch_assoc();
    
        $tik = $row["tik"];
        echo $tik;
    } else {
        echo 'error';
    }
}

$stmt->close();
$sql_search_username->close();
$conn->close();
?>