<?php
include 'db.php';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_POST['auth']) && isset($_POST['newusername'])) {
        $auth = $_POST['auth'];
        $newname = $_POST['newusername'];

    
        if (strlen($newname) > 25) {
            echo "یوزرنیم نمی‌تواند بیشتر از 25 کاراکتر باشد.";
            exit;
        }
 if (strlen($newname) < 5) {
            echo "یوزرنیم نمی‌تواند کمتر از  5 کاراکتر باشد.";
            exit;
        }
        $stmt = $pdo->prepare("SELECT ban FROM loginn WHERE auth = :auth");
        $stmt->execute(['auth' => $auth]);
        $row2 = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row2 && $row2["ban"] == "yes") {
            echo "error ban";
            exit;
        }

        if (preg_match('/^[A-Za-z0-9]+$/', $newname)) {
            $stmt = $pdo->prepare("SELECT * FROM loginn WHERE auth = :auth");
            $stmt->execute(['auth' => $auth]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
            
                $stmt = $pdo->prepare("SELECT * FROM loginn WHERE username = :username");
                $stmt->execute(['username' => $newname]);
                $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($existingUser) {
                    echo "خطا: یوزرنیم قبلاً استفاده شده است.";
                } else {
                    $oldname = $user['username'];

                    $stmt = $pdo->prepare("UPDATE loginn SET username = :username WHERE auth = :auth");
                    $stmt->execute(['username' => $newname, 'auth' => $auth]);

                    $stmt = $pdo->prepare("UPDATE messages SET sender = :newname WHERE sender = :oldname");
                    $stmt->execute(['newname' => $newname, 'oldname' => $oldname]);

                    $stmt = $pdo->prepare("UPDATE messages SET receiver = :newname WHERE receiver = :oldname");
                    $stmt->execute(['newname' => $newname, 'oldname' => $oldname]);

                    echo "ok";
                }
            } else {
                echo "error auth";
            }
        } else {
            echo "یوزرنیم باید فقط شامل حروف و اعداد باشد.";
        }
    }
} catch (PDOException $e) {
    echo "error: " . $e->getMessage();
}
?>