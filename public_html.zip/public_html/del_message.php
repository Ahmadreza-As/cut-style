<?php
include 'db.php';
$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$auth = $conn->real_escape_string($_POST['auth']);

$sql_check_ban = "SELECT ban FROM loginn WHERE auth='$auth'";
$result_check_ban = $conn->query($sql_check_ban);

if ($result_check_ban->num_rows > 0) {
    $row2 = $result_check_ban->fetch_assoc();
    
    if ($row2["ban"] == "yes") {
        echo "error ban";
        exit;
    }
}

$sql_search_username = "SELECT username FROM loginn WHERE auth='$auth'";
$result_search_username = $conn->query($sql_search_username);

if ($result_search_username->num_rows > 0) {

    $filename = $_POST['name'];

    if (!file_exists("pm/" . $filename)) {
        echo 'error: file not found';
        exit;
    }

    
    $jsonData = file_get_contents("pm/" . $filename);

    $data = json_decode($jsonData, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo 'error';
        exit;
    }

    
    $keyToRemove = $_POST['key'];
    $itemRemoved = false;

    foreach ($data as $key => $item) {
        if ($item['key'] === $keyToRemove) {
            unset($data[$key]);
            $itemRemoved = true;
            break;
        }
    }

    if ($itemRemoved) {
        $newJsonData = json_encode(array_values($data));
        file_put_contents("pm/" . $filename, $newJsonData);
        echo 'delete';
    } else {
        echo 'error: pm not found';
    }
} else {
    echo 'error: auth not found';
}

$conn->close();
?>