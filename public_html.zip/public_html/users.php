<?php

include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$auth = $_POST['auth'];

$stmt = $conn->prepare("SELECT ban FROM loginn WHERE auth = ?");
$stmt->bind_param("s", $auth);
$stmt->execute();
$result_ban = $stmt->get_result();
$row2 = $result_ban->fetch_assoc();

if ($row2 && $row2["ban"] == "yes") {
    echo "error ban";
    $conn->close();
    exit;
}

$stmt_username = $conn->prepare("SELECT username FROM loginn WHERE auth = ?");
$stmt_username->bind_param("s", $auth);
$stmt_username->execute();
$result_search_username = $stmt_username->get_result();

if ($result_search_username->num_rows > 0) {

    $row = $result_search_username->fetch_assoc();
    $sender = $row["username"];
} else {
    echo "No results found for the provided auth.";
    $conn->close();
    exit;
}

$sql = "SELECT * FROM loginn";
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        $data[] = array(
            'username' => $row["username"],
            'icon' => $row["icon"],
            'name' => $row["name"],
            'tik' => $row["tik"]
        );
    }
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($data);
?>