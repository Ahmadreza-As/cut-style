<?php
$servername = "localhost";
$username = "pidoir_pidoir";
$password = "(m47eerp6Qr^";
$dbname = "pidoir_pido";
?>